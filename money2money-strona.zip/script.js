const menuButton = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav-links');
const topbar = document.querySelector('.topbar');
const toTop = document.querySelector('.to-top');
const navLinks = [...document.querySelectorAll('.nav-links a[href^="#"]')];

menuButton?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.textContent = open ? '✕' : '☰';
  menuButton.setAttribute('aria-label', open ? 'Zamknij menu' : 'Otwórz menu');
});

navLinks.forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton?.setAttribute('aria-expanded', 'false');
  if (menuButton) {
    menuButton.textContent = '☰';
    menuButton.setAttribute('aria-label', 'Otwórz menu');
  }
}));

window.addEventListener('scroll', () => {
  const y = window.scrollY;
  topbar?.classList.toggle('scrolled', y > 8);
  toTop?.classList.toggle('visible', y > 500);
}, { passive: true });

toTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const observedSections = ['konta', 'pozyczki', 'ubezpieczenia', 'praca', 'kontakt']
  .map(id => document.getElementById(id))
  .filter(Boolean);

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      navLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
      });
    });
  }, { rootMargin: '-30% 0px -58% 0px', threshold: 0 });

  observedSections.forEach(section => observer.observe(section));
}
